#!/bin/sh

cd `dirname $0`

for i in `ls -1 *.eml 2> /dev/null`; do
  python3 ../../bin/play-smtp.py --client.ip "183.79.209.80" --server.ip "172.16.1.33" "$i"
done

sleep 30

python3 ../../bin/play-dns.py \
 --client.ip "192.168.1.44" --server.ip "192.168.1.2" \
 --loop.count 500 --loop.interval 1000 \
 --dns.type txt --dns.r '${rand.lower_alnum(120)}' '${rand.lower_alnum(32)}.spider.xyz.ru'
