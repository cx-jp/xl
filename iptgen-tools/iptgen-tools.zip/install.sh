#!/bin/sh

cd `dirname $0`
find . -name "*.py" | xargs chmod +x
find . -name "*.sh" | xargs chmod +x
find . -name "*.bin" | xargs chmod +x

mkdir -p /usr/local/iptgen-tools
/bin/cp -rf ./* /usr/local/iptgen-tools/
rm -f /usr/local/iptgen-tools/install.sh
