#!/bin/sh

cd `dirname $0`

for i in `ls -1 *.eml 2> /dev/null`; do
  python3 ../ig-smtp.py \
    --client.ip "${ENDPOINT_IP}" \
    --server.ip "${SMTP_SERVER_IP}" \
    "$i" | iptgen.bin --out.eth "${NIC_NAME}"
done

sleep 30

iptgen.bin --in.file iptgen-dns-tunnel.json --out.eth "${NIC_NAME}"
