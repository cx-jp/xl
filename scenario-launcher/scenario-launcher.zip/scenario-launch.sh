#!/bin/sh

cd `dirname $0`

## Set PATH to iptgen
case `uname -m` in
  x86_64 )
    export PATH=$PATH:`pwd`/iptgen/linux/elf/x64
    ;;
    
  i?86 )
    export PATH=$PATH:`pwd`/iptgen/linux/elf/x86
    ;;
esac

chmod +x ./iptgen/linux/elf/x64/*.bin
chmod +x ./iptgen/linux/elf/x86/*.bin


## Set the environment
while read line ; do
  key=`echo $line | cut -d= -f1 | tr -d "\r"`
  val=`echo $line | cut -d= -f2- | tr -d "\r"`
  key=`eval echo $key`
  val=`eval echo $val`
  if [ "$key" != "" -a "#" != "`echo $line | cut -c1`" ]; then
    eval "export $key=$val"
  fi
done < ./scenario/scenario.config

chmod +x ./scenario/scenario.sh
./scenario/scenario.sh

