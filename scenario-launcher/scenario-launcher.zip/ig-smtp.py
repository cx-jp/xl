#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import argparse
import email.parser
import email.utils
import email.header
import email.policy
import re
from typing import List, Dict, Any

def get_email_addresses(
        msg: email.parser.Parser,
        names: List[str]) -> List[str]:
    """
    Extract email addresses

    :param msg: An email message
    :param names: A list of field names
    :return: A list of email address
    """
    dalist = []
    for name in names:
        dalist += email.utils.getaddresses(msg.get_all(name, []))
    return [a[1] for a in dalist]


def make_smtp_script(
        client_ip: str,
        smtp_ip: str,
        smtp_host: str,
        senders: List[str],
        recipients: List[str],
        eml: email.message.EmailMessage,
        logging: bool = False) -> str:
    """
    Generate a smtp script for iptgen

    :param client_ip: A client IP address
    :param smtp_ip: A smtp server IP address
    :param senders: An email address list of senders
    :param recipients: An email address list of recepients
    :param eml: An email message to be sent.
    :return: A iptgen script.
    """
    # Convert the email into hidden dot format
    heml = []
    for l in eml.as_string().splitlines():
        heml.append('.' + l if l[:1] == '.' else l)
    heml.append('.')

    # Create a smtp session
    sess = []
    sess.append(['tcp.recv', 'text', ['220 SMTP Service Ready']])
    sess.append(['tcp.send', 'text', [f'EHLO [{client_ip}]']])
    sess.append(['tcp.recv', 'text', [f'250-{smtp_host}', '250 OK']])
    sess.append(['tcp.send', 'text', ['RSET']])
    sess.append(['tcp.recv', 'text', ['250 OK']])
    for s in senders:
        sess.append(['tcp.send', 'text', [f'MAIL FROM:<{s}>']])
        sess.append(['tcp.recv', 'text', ['250 OK']])

    for r in recipients:
        sess.append(['tcp.send', 'text', [f'RCPT TO:<{r}>']])
        sess.append(['tcp.recv', 'text', ['250 OK']])
    sess.append(['tcp.send', 'text', ['DATA']])
    sess.append(['tcp.recv', 'text', ['354 Start mail input; end with <CRLF>.<CRLF>']])
    sess.append(['tcp.send', 'text', heml])
    sess.append(['tcp.recv', 'text', ['250 OK']])
    sess.append(['tcp.send', 'text', ['QUIT']])
    sess.append(['tcp.recv', 'text', ['221 OK']])
    sess.append(['tcp.shutdown'])
    
    if logging:
        sess.extend(make_smtp_status_log(senders, recipients, eml))

    js = {}
    js['client'] = client_ip
    js['server'] = f'{smtp_ip}:25'
    js['sequence'] = sess

    return json.dumps(js, indent=2)


def make_smtp_status_log(
        senders: List[str],
        recipients: List[str],
        eml: email.message.EmailMessage) -> List[str]:
    # Create a smtp status log
    msgid = ''
    if 'Message-Id' in eml:
        m = re.fullmatch(r'\s*<\s*([^\s]+)\s*>\s*', eml['Message-Id'])
        if m:
            msgid = m.group(1)
    
    subject = ''
    if 'Subject' in eml:
        subject = encode_email_field(eml['Subject'])
    
    email = json.dumps(make_mime_entity_struct(eml))
    
    logs = []
    for sender in senders:
        for recipient in recipients:
            logs.append([
                'sys.log.syslog',
                'mail',
                'info',
                f'phase=receive, op=relay, from={sender}, to={recipient}, msgid={msgid}, subject={subject}, status=enqueue, email={email}'
            ])
    return logs


def encode_email_field(val: str) -> str:
    return email.header.Header(val).encode()


def make_mime_entity_struct(eml: email.message.EmailMessage, is_root: bool = True) -> Dict[str, Any]:
    mobj = {}
    if 'content-type' in eml:
        mobj['content-type'] = {
            'type': eml.get_content_maintype(),
            'subtype': eml.get_content_subtype(),
            'params': {k:encode_email_field(v) for k,v in eml['content-type'].params.items()}
        }
    
    if 'content-disposition' in eml:
        mobj['content-disposition'] = {
            'type': eml.get_content_disposition(),
            'params': {k:encode_email_field(v) for k,v in eml['content-disposition'].params.items()}
        }
    
    if is_root:
        mobj['header'] = {k:encode_email_field(v) for k,v in eml.items()}
    
    parts = []
    for part in eml.iter_parts():
        parts.append(make_mime_entity_struct(part, False))
    if parts:
        mobj['parts'] = parts
    return mobj


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--client.ip', action='store', dest='client_ip', default='127.0.0.1')
    parser.add_argument('--server.name', action='store', dest='server_name')
    parser.add_argument('--server.ip', action='store', dest='server_ip', default='127.0.0.1')
    parser.add_argument('--sender', action='append', dest='sender')
    parser.add_argument('--recipient', action='append', dest='recipient')
    parser.add_argument('--syslog.host', action='store', dest='syslog_host')
    parser.add_argument('-o', '--out', action='store', dest='out', default='-')
    parser.add_argument('eml', action='store')
    args = parser.parse_args()

    # Read a .eml file
    ep = email.parser.Parser(policy=email.policy.default)
    with open(args.eml, 'r') as f:
        eml = ep.parse(f)

    # senders
    senders = [args.sender] if args.sender else get_email_addresses(eml, ['From', 'Sender'])

    # recipients
    recipients = [args.recipient] if args.recipient else get_email_addresses(eml, ['To', 'Cc', 'Bcc'])
    
    # Remove bcc
    del eml['Bcc']

    # Create a SMTP session script
    if not args.server_name:
        args.server_name = args.server_ip
    
    script = make_smtp_script(
        args.client_ip,
        args.server_ip,
        args.server_name,
        senders,
        recipients,
        eml,
        True)
    
    if args.syslog_host:
        script = json.dumps({
            'global': {
                'config': {
                    'syslog': {
                        'host': args.syslog_host
                    }
                }
            }
        }) + '\n' + script

    # Write a script to the file
    if args.out == '-':
        print(script)
    else:
        with open(args.out, 'w') as f:
            f.write(script)
